package com.joe.graphlib;

/**
 * @author Joe Williams
 * @version 1.0
 * @created 23-Jan-2020 6:51:13 PM
 * 
 */
public class Vertex implements java.io.Serializable {
	private long Id;
        private int X;
        private int Y;

        public Vertex(){
            
        }
        
	public Vertex(long id, int x, int y){
            this.Id = id;
            this.X = x;
            this.Y = y;
	}
        public Vertex(long id){
            this.Id = id;
        }
	
	public void setId(long id) {
		this.Id = id;
	}
	public long getId() {
		return this.Id;
	}
        public void setX(int x){
            this.X = x;
        }
        public int getX(){
            return this.X;
        }
        
        public void setY(int y) {
            this.Y = y;
        }
        
        public int getY() {
            return this.Y;
        }
        
        @Override
        public String toString() {
            return "Vertex:" + this.Id;
        }
}

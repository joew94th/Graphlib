package com.joe.graphlib;

import java.util.Vector;

/**
 * @author Joe Williams
 * @version 1.0
 * @created 26-Jan-2020 8:51:13 AM
 */
public class Path extends Vector<Edge> implements java.io.Serializable {

    private Edge edge;
    private final int Weight;
    private final int heaviestPath;
    private Long vertexStart = 0L;
    private Long vertexTarget = 0L;

    public Path(Long v1, Long v2) {
        super();
        this.vertexStart = v1;
        this.vertexTarget = v2;
        this.heaviestPath = 0;
        this.Weight = -1;
    }

    public Path(Edge edge) {
        super();
        this.heaviestPath = 0;
        this.Weight = -1;
        this.add(edge);
    }

    protected int getWeight() {
        int returnVal = 0;
        for (Edge edg : this) {
            returnVal += edg.getWeight();
        }
        return returnVal;
    }

    public double getLength() {
        double returnVal = 0.0;
        for (Edge edg : this) {
            returnVal += edg.getLenth();
        }
        return returnVal;
    }
}

package com.joe.graphlib;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Set;
import java.util.Vector;

/**
 * @author Joe Williams
 * @version 1.0
 * @created 23-Jan-2020 6:51:13 PM
 */
public class Graph implements java.io.Serializable {

    private Hashtable<Long, Edge> Edges = new Hashtable();
    private Hashtable<Long, Vertex> Vertices = new Hashtable();
    private int depth;
    public boolean DEBUG = true;

    public Graph() {

    }

    /**
     * Vertex related methods
     */
    public int getVerticesCount() {
        return Vertices.size();
    }

    public synchronized void addVertex(Vertex vertex) {
        Vertices.put(vertex.getId(), vertex);
    }

    public boolean containVertex(Vertex v) {
        return Vertices.contains(v);
    }

    public Vertex getVertex(long vertexId) {
        return Vertices.get(vertexId);
    }

    public synchronized void removeVertex(Vertex vertex) {
        Vertices.remove(vertex.getId());
    }

    /**
     * ******************************************
     * Edge related methods *****************************************
     */
    /*
	*  	Add pre-existing Edge to collection 
     */
    public synchronized void addEdge(Edge edge) {
        Edges.put(edge.getId(), edge);
    }

    /*
	*	Add new Edge to collection
     */
    public synchronized Edge addEdge(Vertex source, Vertex target, Long Id) {
        Edge edg = new Edge(source, target, Id);
        this.addEdge(edg);
        return edg;
    }

    /*
	*	Get an Edge object by its Id
     */
    public synchronized Edge getEdge(long EdgeId) {
        return Edges.get(EdgeId);
    }

    /*
	*	Get all edges connected to a vertex
     */
    public synchronized ArrayList<Edge> getEdges(Vertex v) {
        ArrayList<Edge> retVal = new ArrayList();
        Set<Long> egs = Edges.keySet();
        for (Long eg : egs) {
            if (Edges.get(eg).getSource() == v || Edges.get(eg).getTarget() == v) {
                retVal.add(Edges.get(eg));
            }
        }
        return retVal;
    }

    /*
	*  Get All Edges
     */
    public synchronized Hashtable<Long, Edge> getEdges() {
        return this.Edges;
    }

    /*
	* Get the number of edges in the collection
     */
    public synchronized int getEdgesCount() {
        return Edges.size();
    }

    /*
	*	Remove an edge
     */
    public synchronized void removeEdge(Edge edge) {
        Edges.remove(edge.getId());
    }

    /* 
	*	Find the edges that connect two verticies
     */
    public synchronized ArrayList<Edge> findPath(Vertex fromVertex, Vertex toVertex) {
        return null;
    }

    public synchronized void getEdgeLengths() {
        Set<Long> keys = Edges.keySet();
        for (Long key : keys) {
            Edge edge = Edges.get(key);
            int x = Math.abs(edge.getSource().getX() - edge.getTarget().getX());
            int y = Math.abs(edge.getSource().getY() - edge.getTarget().getY());
            edge.setLength(Math.hypot(x, y));
        }
    }

    public Path findPath(Long startVertexId, Long targetVertexId) {

        Vector<Edge> startEdges;
        Path shortestPath = null;

        startEdges = getVertexEdges(startVertexId);
        Collections.sort(startEdges);

        // look for edges with our target vertex
        for (Edge edg : startEdges) {
            Path newPath = null, workPath = new Path(edg);
            edg.visited();
            if (edg.getEnd().getId() != targetVertexId) {
                // if target not found, we must dig deeper with recursion 
                depth++; // set recursion level for debugging
                newPath = findPath(edg.getEnd().getId(), targetVertexId);
                depth--;
                if(newPath == null)
                    continue;
                else {
                    workPath.addAll(newPath);
                }
            }
            if (shortestPath == null) {
                shortestPath = workPath;
            } else if (workPath.getLength() < shortestPath.getLength()) {
                shortestPath = workPath;
            } else if (workPath.getWeight() > shortestPath.getWeight()) {
                shortestPath = workPath;
            }
        }
        // add the best Edge to the Path collection           
        DEBUG("[Returning path ]" + (shortestPath == null ? "[null]" : shortestPath), true);
        return shortestPath;
    }

// find the immediate edges to origin vertex
    private Vector<Edge> getVertexEdges(Long vertexId) {
        Long vStart;
        Edge edge;
        Vector<Edge> returnValue = new Vector();
        Set<Long> edgeKeys = Edges.keySet();
        for (Long edgeKey : edgeKeys) {
            edge = Edges.get(edgeKey);
            vStart = edge.getStart().getId();
            if (vStart.equals(vertexId)) {
                returnValue.add(edge);
            }
        }
        return returnValue;
    }

    private void DEBUG(String str, boolean newLine) {
        if (DEBUG == true) {
            StringBuffer strBuff = new StringBuffer();
            for (int i = 0; i < this.depth; i++) {
                strBuff.append("\t");
            }
            if (null == str) {
                str = "[null]";
            }
            strBuff.append(str);
            if (newLine == true) {
                System.out.println(strBuff);
            } else {
                System.out.print(strBuff);
            }
        }
    }

    /**
     * ************************************************************
     * Serialization Methods
     * *************************************************************
     */
    public synchronized void writeObject(ObjectOutputStream out) throws IOException {
        out.writeObject(Vertices);
        out.writeObject(Edges);
    }

    public synchronized void readObject(ObjectInputStream in) throws ClassNotFoundException, IOException {
        Vertices = (Hashtable<Long, Vertex>) in.readObject();
        Edges = (Hashtable<Long, Edge>) in.readObject();
    }
}

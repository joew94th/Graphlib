package com.joe.graphlib;


/**
 * @author Joe Williams
 * @version 1.0
 * @created 23-Jan-2020 6:51:13 PM
 */
public class Edge implements java.io.Serializable, Comparable<Edge>{

	private Directions Direction;
	private long Id;
	private String Label;	
	private Vertex source;
	private Vertex target;
	private int Weight;
        private double length;
        private int visited = 0;

	public Edge(){
             this.Direction = Directions.SRC2TGT;
             this.length = Double.MAX_VALUE;             
	}	
	
	public Edge(Vertex src, Vertex tgt, Long Id) {
		this.setSource(src);
		this.setTarget(tgt);
		this.setId(Id);
                this.Direction = Directions.SRC2TGT;
	}
	public double getLenth() {
            return this.length;
        }
        
        public void setLength(double length){
            this.length = length;
        }
        
	public Directions getDirection(){
		return this.Direction;
	}
        public Vertex getStart() {
            if(this.getDirection() == Directions.SRC2TGT)
                return this.getSource();
            else
                return this.getTarget();
        }
        
        public Vertex getEnd() {
            if(this.getDirection() == Directions.SRC2TGT)
                return this.getTarget();
            else
                return this.getSource();
        }
        
        public void visited(){
            this.visited++;
        }
        
        public int getVisited(){
            return this.visited;
        }
        
	public long getId() {
		return this.Id;
	}
	public String getLabel() {
		return this.Label;
	}
	public Vertex getSource() {
		return this.source;
	}
	public Vertex getTarget() {
		return this.target;
	}
	public int getWeight() {
		return this.Weight;
	}
	public void setDirection(Directions direction) {
		this.Direction = direction;
	}
	public final void setId(long id) {
		this.Id = id;
	}
	public void setLabel(String label) {
		this.Label = label;
	}
	public final void setSource(Vertex source) {
		this.source = source;
	}
	public final void setTarget(Vertex target) {
		this.target = target;
	}
	public void setWeight(int weight) {
		this.Weight = weight;
	}
        
        @Override
        public int compareTo(Edge other){
            if(this.visited < other.getVisited())
                return -1;
            else if(this.visited > other.getVisited())
                return 1;
            else
                return 0;
        }
        
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(" ");
            sb.append(this.Id);            
            sb.append(" :");
            sb.append(this.Label);            
            sb.append("\t : ");
            sb.append(this.source.toString()); 
            if(this.Direction == Directions.SRC2TGT)
                sb.append(" -> ");
            else
                sb.append(" <- ");
            sb.append(this.target.toString());               
            sb.append(" Weight:");
            sb.append(this.Weight); 
            sb.append(" Length:");
            sb.append(this.length);
            return sb.toString();
        }
}
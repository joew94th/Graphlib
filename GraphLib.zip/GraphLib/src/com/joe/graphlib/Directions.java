package com.joe.graphlib;

/**
 * @author Joe Williams
 * @version 1.0
 * @created 23-Jan-2020 6:51:13 PM
 */
public enum Directions {
	NONE,
	SRC2TGT,
	TGT2SRC
}

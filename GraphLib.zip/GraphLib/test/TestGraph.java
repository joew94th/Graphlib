import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import com.joe.graphlib.*;

public class TestGraph implements Runnable {
	private static final int TEST_COUNT = 5;
	private static final String SUCCESS = "***Success***";
	private static final boolean PRINT_SWITCH = false;
	static int THREADS = 1;
	public Graph graph;
	private String threadName;
	
	public TestGraph() {
		graph = new Graph();
		assert graph != null : "Graph object is null";
	}
	
        @Override
	public void run() {
		Random rand = new Random();		
		threadName = Thread.currentThread().getName() + rand.nextInt(100);
		this.addVertex_Test();
		this.getVertex_Test();	
		this.removeVertex_Test();
		this.addEdge_Test();
		this.getEdge_Test();
		this.getEdges_Test();
		this.saveData();		
		this.graph = new Graph();
		this.readData();
		this.getVertex_Test();
		this.getEdges_Test();
		this.getShortestPath();
	}

	public static void main(String[] args) {
		
		for(int i=0; i<THREADS;i++) {
			(new Thread(new TestGraph())).start();
			System.out.println("************************THREAD STARTED**************************");	
		}	
	}	
	
	/*************************************************************************
	*   Vertex tests
	*/

	public void addVertex_Test() {
		PRINT(":Testing addVertex()...");		
		for (int i=0; i<TEST_COUNT; i++){
			Vertex v = new Vertex();
			assert v != null : "Vertex is null";
			v.setId(i);
			assert graph != null : "Graph object is null";
			graph.addVertex(v);
		}
		assert graph.getVerticesCount() != 0 :  "Vertices is empty";
		assert graph.getVerticesCount() >= TEST_COUNT : "Vertices size is incorrect";
		PRINT(SUCCESS);		
	}
	
	public void getVertex_Test() {
		PRINT(":Testing getVertex()...");
		for (int i=0; i<TEST_COUNT; i++){
			Vertex v = graph.getVertex(i);
			assert v != null : "Vertex is null";
			assert v.getId() == i : "Unexpected Vertex Id";
		}
		PRINT(SUCCESS);	
	}
	
	public void removeVertex_Test() {
		PRINT(":Testing removeVertex()...");
		Vertex v;
		for (int i=0; i< TEST_COUNT; i++){			
			v = graph.getVertex(i);
			assert v != null : "Vertex object is null";
			graph.removeVertex(v);
			assert graph.getVertex(i) == null : "Vertex still in collection";
		}
		assert graph.getVerticesCount() == 0 : "Verticies not empty";		
		PRINT(SUCCESS);
	}
	/*********************************************************************
	*     Edge Tests
	*/
	
	public void addEdge_Test() {
		PRINT(":Testing addEdge()...calls addVertex_Test()");
		this.addVertex_Test();
		Edge edg = null;
		for (int i=0; i<TEST_COUNT; i++)
		{
			// link each Vertex to the next one in the list. Link last one to the first, start Id at 1000
			edg = graph.addEdge(graph.getVertex(i), graph.getVertex(i+1 < TEST_COUNT ? i+1 : 0 ), Long.valueOf(i+TEST_COUNT));  			
			assert edg != null : "No edge object returned";
			edg.setLabel("Connection " + i);
			edg.setDirection(Directions.SRC2TGT);
			edg.setWeight(1);
		}
		PRINT(":\t" + graph.getEdgesCount() + " Edges added...");
		PRINT(SUCCESS);
	}	
	
	public void getEdge_Test() {
		PRINT(":Testing getEdge()...");
		Edge edg = null;
		for (int i=0; i< TEST_COUNT; i++) {
			edg = graph.getEdge(TEST_COUNT+i); // get edge by Id
			assert edg != null : "Edge is null";
			Vertex v = edg.getSource();
			assert v != null : "Edge vertex source is null";
			v = edg.getTarget();
			assert v != null : "Edge vertex target is null";		
		}
		PRINT(SUCCESS);
	}
	
	public void getEdges_Test() {
		PRINT(":Testing getEdges()...");
		StringBuffer strBuff;
		ArrayList<Edge> edgs = null;
		Vertex v,v1,v2 = null;
		for( int i = 0; i < TEST_COUNT; i++) {
			v = graph.getVertex(i);
			assert v != null : "Vertex object is null";
			System.out.println(this.threadName + ":Vertex "+ v.getId());
			edgs = graph.getEdges(v);
			assert edgs != null : "Edgs list is null";
			for(int j=0; j<edgs.size(); j++) {
				Edge eg1 = edgs.get(j);
				assert eg1 != null : "Edge is null";	
				v1 = eg1.getSource();
				assert v1 != null : "Source vertex is null ";
				v2 = eg1.getTarget();
				assert v2 != null : "Target vertex is null ";
				strBuff = new StringBuffer();
				strBuff.append(":\tEdge: ");
				strBuff.append(eg1.getId());
				strBuff.append(" Label:");
				strBuff.append(eg1.getLabel());
				strBuff.append(" Source:");
				strBuff.append(v1.getId());
				strBuff.append(" Target:");
				strBuff.append(v2.getId());
				strBuff.append(" Direction:");
				strBuff.append(eg1.getDirection());
				strBuff.append(" Weight:");
				strBuff.append(eg1.getWeight());
				PRINT(strBuff.toString()); 
			}	
		}		
		PRINT(SUCCESS);
	}
	
	/*************************************************************************
	*   
        * Serialization Tests
	*/	
	public void saveData() {
		PRINT("****\n* Testing serialization...");
		try {
			FileOutputStream fileOut = new FileOutputStream("Graph"+threadName+".ser");
			assert fileOut != null : "Output file handle is null";
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			assert out != null : "Output object stream is null";
			graph.writeObject(out);				
			out.close();
			fileOut.close();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		PRINT(SUCCESS);		
	}
	
	public void readData() {
		PRINT("****\n*Testing deserialization...");
		try {
			FileInputStream fileIn = new FileInputStream("Graph"+threadName+".ser");
			assert fileIn != null : "Input file handle is null";
			ObjectInputStream in = new ObjectInputStream(fileIn);
			assert in != null : "Input object stream is null";
			graph.readObject(in);
			in.close();
			fileIn.close();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}	
		PRINT(SUCCESS);
	}
	
	/********************************************************************
	*       Path discovery tests
	*/
	public void getShortestPath() {
		PRINT("****\n*Testing Path discovery...");
		StringBuffer strBuff = new StringBuffer();
		Path path = new Path(2L, 5L, graph.getEdges());
		for(Edge edge : path) {
			strBuff = new StringBuffer();
			strBuff.append(":\tEdge: ");
			strBuff.append(edge.getId());
			strBuff.append(" Label:");
			strBuff.append(edge.getLabel());
			strBuff.append(" Source:");
			strBuff.append(edge.getSource().getId());
			strBuff.append(" Target:");
			strBuff.append(edge.getTarget().getId());
			strBuff.append(" Direction:");
			strBuff.append(edge.getDirection());
			strBuff.append(" Weight:");
			strBuff.append(edge.getWeight());
			PRINT(strBuff.toString());			
		}
		PRINT(SUCCESS);
	}
	
	/****************************************
	*  Utility Methods
        * @param description contains the string to be written to the console
	*/
	public void PRINT(String description) {
		if(PRINT_SWITCH == true)
			System.out.println(this.threadName + description);
	}
}
